import typer
import os
import subprocess
from pynav.console import console
from pathlib import Path

app = typer.Typer()


@app.command()
def go(path: str):

    try:
        lines = (Path.home() / ".nav.conf").read_text().splitlines()
    except FileNotFoundError as err:
        console.print(str(err) + ": Populate with `nav add`")
        raise typer.Exit(1)

    search = list(filter(lambda l: path.lower() in l.lower(), lines))

    if len(search) > 1:
        [console.print(i, l) for i, l in enumerate(search)]
        selection = typer.prompt(
            f"More than one matching path found\n Select desired path"
        )
        out_path = search[int(selection)]
    else:
        out_path = search[0]

    # Flatten and clean path string for new lines
    out_path = Path(out_path).expanduser()

    typer.launch(str(out_path))


@app.command()
def add():  # add global flag here?
    console.print("Add paths to nav file", style="magenta", justify="left")
    console.print(
        "These paths can be accessed with `nav go -path`", style="green", justify="left"
    )  # make nicer??

    # Get path of file being run
    config_file = Path.home() / ".nav.conf"

    if not Path.exists(config_file):
        Path(config_file).touch()

    if "ix" in os.name:
        subprocess.run(["xdg-open", config_file])
    else:
        # os.system(f"Code {config_file}")
        os.startfile(config_file)
