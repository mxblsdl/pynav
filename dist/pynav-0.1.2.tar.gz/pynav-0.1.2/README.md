# Pynav

A simple CLI for navigating to predefined directories