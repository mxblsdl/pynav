# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pynav']

package_data = \
{'': ['*']}

install_requires = \
['typer[all]>=0.6.1,<0.7.0']

entry_points = \
{'console_scripts': ['nav = pynav.main:app']}

setup_kwargs = {
    'name': 'pynav',
    'version': '0.1.2',
    'description': 'A simple CLI for navigating to predefined directories',
    'long_description': '# Pynav\n\nA simple CLI for navigating to predefined directories',
    'author': 'mxblsdl',
    'author_email': 'maxblasdel@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
